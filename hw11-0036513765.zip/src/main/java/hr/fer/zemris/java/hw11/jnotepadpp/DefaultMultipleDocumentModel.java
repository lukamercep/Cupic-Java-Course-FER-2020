package hr.fer.zemris.java.hw11.jnotepadpp;

import java.awt.Color;
import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Class DefaultMultipleDocumentModel is a default implementation of
 * MultipleDocumentModel. This class also extends JTabbedPane for 
 * representing all SingleDocumentModels stored in this class.
 * 
 * @author Luka Merćep
 *
 */
public class DefaultMultipleDocumentModel extends JTabbedPane implements MultipleDocumentModel {
	
	/**
	 * List of SingleDocumentModel stored in this class
	 */
	private List<SingleDocumentModel> documents;
	
	/**
	 * current document user is working on
	 */
	private SingleDocumentModel currentDocument;
	
	/**
	 * List of listeners that need to be informed when 
	 * document is removed, added or changing from one to another.
	 */
	private List<MultipleDocumentListener> listeners;
	
	/**
	 * Red icon representing that there is some changes that are not stored
	 */
	private ImageIcon redIcon = null;
	
	/**
	 * Green icon representing all changes are stored
	 */
	private ImageIcon greenIcon = null;
	
	/**
	 * length of a currentDocument is written on this label
	 */
	private JLabel length;
	
	/**
	 * Private helper method for loading icons
	 * 
	 * @param color
	 */
	private void loadIcon(String color) {
		InputStream is = this.getClass().getResourceAsStream("icons/" + color  + "-icon.png");
		if (is == null) {
			//this should not happen
			System.out.println("There was an error while loading " + color + " icon.");
		}
		try {
			byte[] bytes = is.readAllBytes();
			is.close();
			if (color.equals("red")) {
				redIcon = new ImageIcon(bytes);
			} else {
				greenIcon = new ImageIcon(bytes);
			}
		} catch (IOException ex) {
			//this should not happen
			System.out.println("There was an error while loading " + color + " icon.");
		}
	}
	
	/**
	 * Private helper method for scaling red and green icon
	 */
	private void scaleIcons() {
		Image imageRed = redIcon.getImage();
		Image scaledImageR = imageRed.getScaledInstance(13, 13,  java.awt.Image.SCALE_SMOOTH);
		redIcon = new ImageIcon(scaledImageR);
		
		Image imageGreen = greenIcon.getImage();
		Image scaledImageG = imageGreen.getScaledInstance(13, 13,  java.awt.Image.SCALE_SMOOTH);
		greenIcon = new ImageIcon(scaledImageG);
	}
	
	/**
	 * Constructor of DefaultMultipleDocumentModel.
	 * 
	 * It is also given a JLabel length where length of a 
	 * currentDocument is written.
	 * 
	 * @param length
	 */
	public DefaultMultipleDocumentModel(JLabel length) {
		documents = new ArrayList<>();
		listeners = new ArrayList<>();
		loadIcon("red");
		loadIcon("green");
		scaleIcons();
		
		addChangeListener( e -> {
			SingleDocumentModel previousDocument = currentDocument;
			if (getTabCount() == 0) {
				currentDocument = null;
			} else {
				currentDocument = documents.get(getSelectedIndex());
			}
			
			//notify all changed documents
			for (int i=0; i<listeners.size(); i++) {
				listeners.get(i).currentDocumentChanged(previousDocument, currentDocument);
			}
		});
		
		this.length = length;
	}
	
	@Override
	public Iterator<SingleDocumentModel> iterator() {
		return documents.iterator();
	}

	@Override
	public SingleDocumentModel createNewDocument() {
		SingleDocumentModel newDocument = new DefaultSingleDocumentModel(null, ""); 
		documents.add(newDocument);
		//add("(unnamed)", new JScrollPane(newDocument.getTextComponent()));
		insertTab("(unnamed)", redIcon, new JScrollPane(newDocument.getTextComponent()),
				"(unnamed)", getTabCount());
		
		newDocument.addSingleDocumentListener(new SingleDocumentListener() {
			
			@Override
			public void documentModifyStatusUpdated(SingleDocumentModel model) {
				int index = documents.indexOf(model);
				length.setText(" length:" + documents.get(index).getTextComponent().getText().length());
				if (model.isModified()) {
					setIconAt(index, redIcon);
				} else {
					setIconAt(index, greenIcon);
				}
			}
			
			@Override
			public void documentFilePathUpdated(SingleDocumentModel model) {
				if (model.getFilePath() == null) {
					setToolTipTextAt(documents.indexOf(model), "(unnamed)");
				} else {
					setToolTipTextAt(documents.indexOf(model), model.getFilePath().toAbsolutePath().toString());
				}
			}
		});
		
		currentDocument = newDocument;
		setSelectedIndex(getNumberOfDocuments()-1);
		return newDocument;
	}

	@Override
	public SingleDocumentModel getCurrentDocument() {
		return currentDocument;
	}

	@Override
	public SingleDocumentModel loadDocument(Path path) {
		if (path == null) {
			throw new IllegalArgumentException("path can not be null.");
		}
		for (int i=0; i<documents.size(); i++) {
			if (documents.get(i).getFilePath() == null) {
				continue;
			}
			if (documents.get(i).getFilePath().toAbsolutePath().compareTo(path.toAbsolutePath()) == 0) {
				currentDocument = documents.get(i);
				setSelectedIndex(i);
				return currentDocument;
			}
		}
		
		try {
			byte[] fileBytes = Files.readAllBytes(path);
			String text = new String(fileBytes, StandardCharsets.UTF_8);
			SingleDocumentModel newDocument = new DefaultSingleDocumentModel(path, text);
			newDocument.setModified(false);
			documents.add(newDocument);
			insertTab(path.getFileName().toString(), greenIcon, 
					new JScrollPane(newDocument.getTextComponent()),
					path.toAbsolutePath().toString(), getTabCount());
			
			newDocument.addSingleDocumentListener(new SingleDocumentListener() {
				
				@Override
				public void documentModifyStatusUpdated(SingleDocumentModel model) {
					int index = documents.indexOf(model);
					length.setText(" length:" + documents.get(index).getTextComponent().getText().length());
					if (model.isModified()) {
						setIconAt(index, redIcon);
					} else {
						setIconAt(index, greenIcon);
					}
				}
				
				@Override
				public void documentFilePathUpdated(SingleDocumentModel model) {
					if (model.getFilePath() == null) {
						setToolTipTextAt(getTabCount()-1, "(unnamed)");
					} else {
						setToolTipTextAt(getTabCount()-1, model.getFilePath().toAbsolutePath().toString());
					}
				}
			});
			
			currentDocument = newDocument;
			setSelectedIndex(getNumberOfDocuments()-1);
			return newDocument;
		} catch (IOException ex) {
			return null;
		}
		
	}

	@Override
	public void saveDocument(SingleDocumentModel model, Path newPath) {
		if (newPath != null) {
			for (int i=0; i<documents.size(); i++) {
				if (documents.get(i).getFilePath() == null) {
					continue;
				}
				if (documents.indexOf(model) == i) {
					continue;
				}
				if (documents.get(i).getFilePath().toAbsolutePath().equals(newPath.toAbsolutePath())) {
					throw new IllegalArgumentException("can not use existing"
							+ " path from other document as path.");
				}
			}
		}
		byte[] bytes = model.getTextComponent().getText().getBytes(StandardCharsets.UTF_8);
		try {
			Files.write(newPath, bytes);
			setTitleAt(documents.indexOf(model), newPath.getFileName().toString());
			documents.get(documents.indexOf(model)).setFilePath(newPath);
		} catch (IOException e) {
			throw new IllegalArgumentException();
		}
		model.setModified(false);
	}

	@Override
	public void closeDocument(SingleDocumentModel model) {
		remove(getSelectedComponent());
		documents.remove(model);
	}

	@Override
	public void addMultipleDocumentListener(MultipleDocumentListener l) {
		listeners.add(l);
	}

	@Override
	public void removeMultipleDocumentListener(MultipleDocumentListener l) {
		listeners.remove(l);
	}

	@Override
	public int getNumberOfDocuments() {
		return documents.size();
	}
	
	@Override
	public SingleDocumentModel getDocument(int index) {
		return documents.get(index);
	}
}
