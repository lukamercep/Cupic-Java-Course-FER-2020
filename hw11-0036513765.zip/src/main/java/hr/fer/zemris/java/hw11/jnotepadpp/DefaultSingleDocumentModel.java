package hr.fer.zemris.java.hw11.jnotepadpp;


import java.awt.event.ComponentListener;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Class is a defaulf implementation of interface SingleDocumentModel
 * 
 * @author Luka Merćep
 *
 */
public class DefaultSingleDocumentModel implements SingleDocumentModel {
	
	/**
	 * Path of this document
	 */
	private Path path;
	
	/**
	 * text stored in this document
	 */
	private String text;
	
	/**
	 * JTextArea of this document
	 */
	private JTextArea textArea;
	
	/**
	 * modified status of this document
	 */
	private boolean modified = true;
	
	/**
	 * List of SingleDocumentListener that need to be informed 
	 * when changes are made on this document
	 */
	private List<SingleDocumentListener> listeners;
	
	/**
	 * Default constructor of class DefaultSingleDocumentModel
	 * 
	 * @param path
	 * @param text
	 */
	public DefaultSingleDocumentModel(Path path, String text) {
		this.path = path;
		this.text = text;
		textArea = new JTextArea(text);
		listeners = new ArrayList<SingleDocumentListener>();
		
		textArea.getDocument().addDocumentListener(new DocumentListener() {
			
			public void removeUpdate(DocumentEvent e) {
				modified = true;
				notifyAllListeners();
			}
			
			public void insertUpdate(DocumentEvent e) {
				modified = true;
				notifyAllListeners();
			}
			
			public void changedUpdate(DocumentEvent e) {
				modified = true;
				notifyAllListeners();
			}
		});
	}
	
	/**
	 * Private method that informs all listeners that 
	 * modified status was changed
	 */
	private void notifyAllListeners() {
		for (int i=0; i<listeners.size(); i++) {
			listeners.get(i).documentModifyStatusUpdated(this);
		}
	}
	
	@Override
	public JTextArea getTextComponent() {
		return textArea;
	}
	
	@Override
	public Path getFilePath() {
		return path;
	}
	
	@Override
	public void setFilePath(Path path) {
		if (path == null) {
			throw new IllegalArgumentException("path can not be null.");
		}
		this.path = path;
		for (int i=0; i<listeners.size(); i++) {
			listeners.get(i).documentFilePathUpdated(this);
		}
	}
	
	@Override
	public boolean isModified() {
		return modified;
	}
	
	@Override
	public void setModified(boolean modified) {
		this.modified = modified;
		notifyAllListeners();
	}
	
	@Override
	public void addSingleDocumentListener(SingleDocumentListener l) {
		listeners.add(l);
	}

	@Override
	public void removeSingleDocumentListener(SingleDocumentListener l) {
		listeners.remove(l);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof DefaultSingleDocumentModel)) {
			return false;
		}
		return this.textArea == ((DefaultSingleDocumentModel)(obj)).textArea;
	}
}
