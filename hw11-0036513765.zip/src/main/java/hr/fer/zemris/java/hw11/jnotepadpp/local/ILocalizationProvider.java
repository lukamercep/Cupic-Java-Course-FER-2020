package hr.fer.zemris.java.hw11.jnotepadpp.local;

/**
 * Interface ILocalizationProvider models one simple i18n localization
 * provider
 * 
 * @author Luka Merćep
 *
 */
public interface ILocalizationProvider {
	
	/**
	 * Method adds new localization listener
	 * 
	 * @param l
	 */
	void addLocalizationListener(ILocalizationListener l);
	
	/**
	 * Method removes localization listener
	 * 
	 * @param l
	 */
	void removeLocalizationListener(ILocalizationListener l);
	
	/**
	 * Method returns current language for localization
	 * 
	 * @return
	 */
	String getCurrentLanguage();
	
	/**
	 * Method return value for a given key in this localization
	 * 
	 * @param key
	 * @return
	 */
	String getString(String key);
}
