package hr.fer.zemris.java.hw11.jnotepadpp.local;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;

/**
 * Class LocalizableAction extends AbstractAction is 
 * used for Actions whose names should be localizable
 * 
 * @author Luka Merćep
 *
 */
public abstract class LocalizableAction extends AbstractAction {
	
	/**
	 * String used as key for getting names of this localizable action
	 */
	private String key;
	
	/**
	 * loaclization provider used for localization of this Action
	 */
	private ILocalizationProvider lp;
	
	/**
	 * Constructor for class LocalizableAction given its key and 
	 * localization provider.
	 * 
	 * @param key
	 * @param lp
	 */
	public LocalizableAction(String key, ILocalizationProvider lp) {
		this.key = key;
		this.lp = lp;
		
		putValue(Action.NAME, lp.getString(key));
		
		lp.addLocalizationListener(() -> {
			putValue(Action.NAME, lp.getString(key));
		});
	}
}
