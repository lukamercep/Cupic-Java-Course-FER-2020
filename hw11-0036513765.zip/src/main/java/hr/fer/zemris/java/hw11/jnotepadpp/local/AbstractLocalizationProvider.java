package hr.fer.zemris.java.hw11.jnotepadpp.local;

import java.util.ArrayList;
import java.util.List;

/**
 * Class AbstractLocalizationProvider is abstract class that implements some of the 
 * ILocalizationProvider methods.
 * 
 * @author Luka Merćep
 *
 */
public abstract class AbstractLocalizationProvider implements ILocalizationProvider {
	
	/**
	 * List of ILocalizationListener listeners
	 */
	private List<ILocalizationListener> listeners;
	
	/**
	 * Public constructor for this class
	 */
	public AbstractLocalizationProvider() {
		listeners = new ArrayList<>();
	}
	
	@Override
	public void addLocalizationListener(ILocalizationListener l) {
		listeners.add(l);
	}

	@Override
	public void removeLocalizationListener(ILocalizationListener l) {
		listeners.remove(l);
	}
	
	/**
	 * This method triggers all listeners
	 */
	public void fire() {
		for (int i=0; i<listeners.size(); i++) {
			listeners.get(i).localizationChanged();
		}
	}
}
