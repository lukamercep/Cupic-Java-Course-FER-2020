package hr.fer.zemris.java.hw11.jnotepadpp.local;

/**
 * Class LocalizationProviderBridge is used as a bridge for 
 * a localization provider
 * 
 * @author Luka Merćep
 *
 */
public class LocalizationProviderBridge extends AbstractLocalizationProvider {
	
	/**
	 * Connection status of this bridge
	 */
	private boolean connected;
	
	/**
	 * Provider used for localization
	 */
	private ILocalizationProvider provider;
	
	/**
	 * listner that needs to be informed when changes are made
	 */
	private ILocalizationListener listener;
	
	/**
	 * Public constructor for class LocalizationProviderBridge
	 * 
	 * @param provider
	 */
	public LocalizationProviderBridge(ILocalizationProvider provider) {
		this.provider = provider;
		listener = this::fire;
	}
	
	/**
	 * Method used for connection of this bridge.
	 * This method won't do anythig if bridge is already 
	 * connected.
	 * 
	 */
	public void connect() {
		if (!connected) {
			connected = true;
			provider.addLocalizationListener(listener);
		}
	}
	
	/**
	 * Method used for disconnection of bridge
	 * 
	 */
	public void disconnect() {
		connected = false;
		provider.removeLocalizationListener(listener);
	}
	
	@Override
	public String getCurrentLanguage() {
		return provider.getCurrentLanguage();
	}

	@Override
	public String getString(String key) {
		return provider.getString(key);
	}
	
}
