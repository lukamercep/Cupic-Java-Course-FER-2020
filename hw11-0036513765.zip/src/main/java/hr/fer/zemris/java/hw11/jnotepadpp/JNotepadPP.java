package hr.fer.zemris.java.hw11.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.Collator;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.Border;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;

import hr.fer.zemris.java.hw11.jnotepadpp.local.FormLocalizationProvider;
import hr.fer.zemris.java.hw11.jnotepadpp.local.LocalizableAction;
import hr.fer.zemris.java.hw11.jnotepadpp.local.LocalizableJMenu;
import hr.fer.zemris.java.hw11.jnotepadpp.local.LocalizationProvider;

/**
 * Class JNotepadPP is main class for working with program 
 * called "JNotepad++". It can have multiple documents opened.
 * It offers change of case, sorting of lines and a lot more.
 * It also offers a lot of basic operations like copy/cut/paste 
 * operations.
 * 
 * @author Luka Merćep
 *
 */
public class JNotepadPP extends JFrame {
	
	/**
	 * model where all documents are stored
	 */
	private DefaultMultipleDocumentModel model;
	
	/**
	 * private localization provider
	 */
	private FormLocalizationProvider flp = new FormLocalizationProvider(
			LocalizationProvider.getInstance(), this);
	
	/**
	 * Default constructor for class JNotepadPP
	 */
	public JNotepadPP() {
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setLocation(0, 0);
		setSize(600, 600);
		
		initGUI();
	}
	
	/**
	 * menu item for changing case to upper
	 */
	JMenuItem upper;
	
	/**
	 * menu item for changing case to lower
	 */
	JMenuItem lower;
	
	/**
	 * menu item for inverting case of letters
	 */
	JMenuItem invert;
	
	/**
	 * Private helper method for GUI initialization
	 */
	private void initGUI() {
		this.getContentPane().setLayout(new BorderLayout());
		
		setTitle("JNotepad++");
		
		JLabel length = new JLabel();
		JPanel positionAndClock = new JPanel();
		positionAndClock.setLayout(new GridLayout(1, 0));
		JLabel position = new JLabel();
		JLabel clock = new JLabel("clock", JLabel.RIGHT);
		positionAndClock.add(position);
		positionAndClock.add(clock);
		
		JPanel statusBar = new JPanel();
		statusBar.setLayout(new GridLayout(1, 0));
		statusBar.add(length);
		length.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.GRAY));
		statusBar.add(positionAndClock);
		statusBar.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, Color.BLACK));
		getContentPane().add(statusBar, BorderLayout.SOUTH);
		
		model = new DefaultMultipleDocumentModel(length);
		
		this.getContentPane().add(model, BorderLayout.CENTER);
		
		createActions();
		createMenuBar();
		createToolbars();
		
		model.addMultipleDocumentListener(new MultipleDocumentListener() {
			
			@Override
			public void documentRemoved(SingleDocumentModel model) {
			}
			
			@Override
			public void documentAdded(SingleDocumentModel model) {
			}
			
			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				if (currentModel == null) {
					length.setText("");
					position.setText("");
					setTitle("JNotepad++");
				} else {
					length.setText(" length:" + currentModel.getTextComponent().getText().length());
					
					JTextArea textArea = currentModel.getTextComponent();
					
					if (textArea.getCaretListeners().length == 0) {
						CaretListener caretListener = e -> {
							int dotPosition = textArea.getCaret().getDot();
							int markPosition = textArea.getCaret().getMark();
							
							if (dotPosition == markPosition) {
								upper.setEnabled(false);
								lower.setEnabled(false);
								invert.setEnabled(false);
							} else {
								upper.setEnabled(true);
								lower.setEnabled(true);
								invert.setEnabled(true);
							}
							
							try {
								String textBeforeDot = textArea.getText(0, dotPosition);
								long line = textBeforeDot.chars().filter(ch -> ch == '\n').count() + 1;
								int column = 0;
								int length = textBeforeDot.length();
								while (column < length && textBeforeDot.charAt(length-column-1) != '\n') {
									column++;
								}
								column++;
								int selected = Math.abs(dotPosition - textArea.getCaret().getMark());
								position.setText(" Ln:" + line + "   Col:" + column + "   Sel:" + selected);
							} catch (BadLocationException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						};
						textArea.addCaretListener(caretListener);
						caretListener.caretUpdate(null);
					} else {
						for (int i=0; i<textArea.getCaretListeners().length; i++) {
							textArea.getCaretListeners()[i].caretUpdate(null);
						}
					}
					
					if (currentModel.getFilePath() == null) {
						setTitle("(unnamed) - JNotepad++");
					} else {
						setTitle(currentModel.getFilePath().toAbsolutePath().toString() + " - JNotepad++");
					}
				}
			}
		});
		
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				clock.setText(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss").format(
						LocalDateTime.now()
						));
			}
		}, 0, 1000);
		
		
		
		model.createNewDocument();
		
		
		
		addWindowListener(new WindowAdapter() {
			
			@Override
			public void windowClosing(WindowEvent e) {
				exitDocument.actionPerformed(
						new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null) {}
						);
			}
		});
		
		
	}
	
	/**
	 * Action representing new document creation
	 */
	private Action newDocumentAction = new LocalizableAction("New", flp) {
		
		private static final long serialVersionUID = 1L;
		
		public void actionPerformed(ActionEvent e) {
			model.createNewDocument();
		}
	};
	
	/**
	 * Action representing opening of a document
	 */
	private Action openDocument = new LocalizableAction("Open", flp) {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Open file");
			if (fc.showOpenDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No file was selected for opening.",
						"Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			Path path = fc.getSelectedFile().toPath();
			if (!Files.isReadable(path)) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "File " + path.toAbsolutePath() +
						" is not readable.", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if (model.loadDocument(path) == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "An error occurred whil reading file "
						+ path.toAbsolutePath() + ".", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	};
	
	/**
	 * Action representing saving of document
	 */
	private Action saveDocument = new LocalizableAction("Save", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			Path newPath = model.getDocument(index).getFilePath();
			if (newPath == null) {
				JFileChooser fc = new JFileChooser();
				fc.setDialogTitle("Save document");
				if (fc.showOpenDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(JNotepadPP.this, 
							"No file was selected for saving.", 
							"Warning", 
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				newPath = fc.getSelectedFile().toPath();
			}
			
			try {
				model.saveDocument(model.getDocument(index), newPath);
			} catch(IllegalArgumentException ex) {
				JOptionPane.showMessageDialog(JNotepadPP.this, 
						"File path given to this document is already used for opened document.",
						"Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			JOptionPane.showMessageDialog(JNotepadPP.this, 
					"File was successfully saved", 
					"Information", 
					JOptionPane.INFORMATION_MESSAGE);
		}
	};
	
	/**
	 * Action representing "save as" operation on a document
	 */
	private Action saveAsDocument = new LocalizableAction("Saveas", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Save as document");
			if (fc.showOpenDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(JNotepadPP.this, 
						"No file was selected for save as.", 
						"Warning", 
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			Path newPath = fc.getSelectedFile().toPath();
			
			if (Files.exists(newPath, new LinkOption[]{ LinkOption.NOFOLLOW_LINKS}) ) {
				if (JOptionPane.showConfirmDialog(
						JNotepadPP.this,
						"Are you sure you want to override existing content?" +
						"All old content will be lost.", "Warning",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE
						) == JOptionPane.NO_OPTION) {
					return;
				}
			}
			
			try {
				model.saveDocument(model.getDocument(index), newPath);
			} catch(IllegalArgumentException ex) {
				JOptionPane.showMessageDialog(JNotepadPP.this, 
						"File path given to this document is already used for opened document.",
						"Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			JOptionPane.showMessageDialog(JNotepadPP.this, 
					"File was successfully saved as", 
					"Information", 
					JOptionPane.INFORMATION_MESSAGE);
		}
	};
	
	/**
	 * Action representing closing of one document/tab
	 */
	private Action closeDocument = new LocalizableAction("Close", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if (model.getNumberOfDocuments() == 0) {
				return;
			}
			int index = model.getSelectedIndex();
			
			

			if (model.getDocument(index).isModified()) {
				int answer = JOptionPane.showConfirmDialog(JNotepadPP.this, 
						"Do you want to save unsaved progress?",
						"Warning", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
				if (answer == JOptionPane.CANCEL_OPTION) {
					return;
				}
				if (answer == JOptionPane.YES_OPTION) {
					saveDocument.actionPerformed(
							new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null) {}
							);
				}
			}
			model.closeDocument(model.getDocument(index));
		}
	};
	
	/**
	 * Action representing exiting from JNotepad++ program
	 */
	private Action exitDocument = new LocalizableAction("Exit", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			boolean hasUnsaved = false;
			for (int i=0; i<model.getNumberOfDocuments(); i++) {
				if (model.getDocument(i).isModified()) {
					hasUnsaved = true;
				}
			}
			
			if (!hasUnsaved) {
				System.exit(0);
			}
			
			int numberOfDocuments = model.getNumberOfDocuments();
			for (int i=numberOfDocuments-1; i>=0; i--) {
				if (!model.getDocument(i).isModified()) {
					model.closeDocument(model.getDocument(i));
					continue;
				}
				
				model.setSelectedIndex(i);
				
				String fileName = "(unnamed)";
				if (model.getDocument(i).getFilePath() != null) {
					fileName = model.getDocument(i).getFilePath().getFileName().toString();
				}
				
				int answer = JOptionPane.showConfirmDialog(JNotepadPP.this, 
						"Do you want to save changes for " + fileName,
						"Warning", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
				
				if (answer == JOptionPane.CANCEL_OPTION) {
					return;
				}
				if (answer == JOptionPane.YES_OPTION) {
					saveDocument.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null) {});
				}
				model.closeDocument(model.getDocument(i));
			}
			
			dispose();
			System.exit(0);
		}
	};
	
	/**
	 * Action representing cut operation on text
	 */
	private Action cutText = new LocalizableAction("Cut", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			int len = Math.abs(textArea.getCaret().getDot()-textArea.getCaret().getMark());
			if (len == 0) return;
			int offset = Math.min(textArea.getCaret().getDot(),textArea.getCaret().getMark());
			
			String content = "";
			try {
				content = doc.getText(offset, len);
				doc.remove(offset, len);
				StringSelection sel = new StringSelection(content);
				clipboard.setContents(sel, sel);
			} catch (BadLocationException ex) {
			}
			model.getDocument(index).setModified(true);
		}
	};
	
	/**
	 * Action representing copy operation on text
	 */
	private Action copyText = new LocalizableAction("Copy", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			int len = Math.abs(textArea.getCaret().getDot()-textArea.getCaret().getMark());
			if (len == 0) return;
			int offset = Math.min(textArea.getCaret().getDot(),textArea.getCaret().getMark());
			
			String content = "";
			try {
				content = doc.getText(offset, len);
				StringSelection sel = new StringSelection(content);
				clipboard.setContents(sel, sel);
			} catch (BadLocationException ex) {
			}
		}
	};
	
	/**
	 * Action representing paste operation on text
	 */
	private Action pasteText = new LocalizableAction("Paste", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			Transferable t = clipboard.getContents(null);
			try {
				String strToPaste = t.getTransferData(DataFlavor.stringFlavor).toString();
				if (strToPaste.length() == 0) {
					return;
				}
				int offset = Math.min(textArea.getCaret().getDot(), textArea.getCaret().getMark());
				doc.insertString(offset, strToPaste, null);
			} catch(Exception ex) {
				//this should not happen
			}
			
			model.getDocument(index).setModified(true);
		}
	};
	
	/**
	 * Action representing action offering basic informations of a document
	 */
	private Action infoOfDocument = new LocalizableAction("Info", flp) {
		
		private static final long serialVersionUID = 1L;
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			String text = textArea.getText();
			
			int numberOfLines = 1;
			int numberOfNonEmpty = 0;
			
			for (int i=0; i<text.length(); i++) {
				if (text.charAt(i) == '\n') {
					numberOfLines++;
				}
				if (!Character.isWhitespace(text.charAt(i))) {
					numberOfNonEmpty++;
				}
			}
			
			JOptionPane.showMessageDialog(JNotepadPP.this, 
					"Statistical info of document." + 
					"Number of characters in document: " + text.length() + "\n" + 
					"Number of non-blank characters in documnet: " + numberOfNonEmpty + "\n" + 
					"Number of lines in documnet: " + numberOfLines,
					"Information", 
					JOptionPane.INFORMATION_MESSAGE);
		}
	};
	
	/**
	 * Action representing swithing a language to croatian
	 */
	private Action croatianLanguage = new LocalizableAction("Croatian", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			LocalizationProvider.getInstance().setLanguage("hr");
		}
	};
	
	/**
	 * Action representing swithing a language to english
	 */
	private Action englishLanguage = new LocalizableAction("English", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			LocalizationProvider.getInstance().setLanguage("en");
		}
	};
	
	/**
	 * Action representing swithing a language to german
	 */
	private Action germanLanguage = new LocalizableAction("German", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			LocalizationProvider.getInstance().setLanguage("de");
		}
	};
	
	/**
	 * Action that changes all selected text to uppercase
	 */
	private Action uppercase = new LocalizableAction("touppercase", flp) {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			int len = Math.abs(textArea.getCaret().getDot()-textArea.getCaret().getMark());
			if (len == 0) return;
			int offset = Math.min(textArea.getCaret().getDot(),textArea.getCaret().getMark());
			
			String content = "";
			try {
				content = doc.getText(offset, len);
				doc.remove(offset, len);
				doc.insertString(offset, content.toUpperCase(), null);
			} catch (BadLocationException ex) {
			}
		}
	};
	
	/**
	 * Action that changes all selected text to lowercase
	 */
	private Action lowercase = new LocalizableAction("tolowercase", flp) {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			int len = Math.abs(textArea.getCaret().getDot()-textArea.getCaret().getMark());
			if (len == 0) return;
			int offset = Math.min(textArea.getCaret().getDot(),textArea.getCaret().getMark());
			
			String content = "";
			try {
				content = doc.getText(offset, len);
				doc.remove(offset, len);
				doc.insertString(offset, content.toLowerCase(), null);
			} catch (BadLocationException ex) {
			}
		}
	};
	
	/**
	 * Action that inverts case of all selected text
	 */
	private Action invertcase = new LocalizableAction("invertcase", flp) {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			int len = Math.abs(textArea.getCaret().getDot()-textArea.getCaret().getMark());
			if (len == 0) return;
			int offset = Math.min(textArea.getCaret().getDot(),textArea.getCaret().getMark());
			
			String content = "";
			try {
				content = doc.getText(offset, len);
				doc.remove(offset, len);
				
				StringBuilder newString = new StringBuilder();
				
				for (int i=0; i<content.length(); i++) {
					char c = content.charAt(i);
					if (Character.isUpperCase(c)) {
						newString.append(Character.toLowerCase(c));
					} else {
						if (Character.isLowerCase(c)) {
							newString.append(Character.toUpperCase(c));
						} else {
							newString.append(c);
						}
					}
				}
				
				doc.insertString(offset, newString.toString(), null);
			} catch (BadLocationException ex) {
			}
		}
	};
	
	/**
	 * Private helper method that does all work for 
	 * Actions ascending, descending and unique operations.
	 * 
	 * @param coefficient
	 */
	private void ascDescAndUnique(int coefficient) {
		int index = model.getSelectedIndex();
		JTextComponent c = model.getDocument(index).getTextComponent();
		Document doc = c.getDocument();
		Element root = doc.getDefaultRootElement();
		
		int rowBeg = root.getElementIndex(c.getCaret().getMark());
		int rowEnd = root.getElementIndex(c.getCaret().getDot());
		
		if (rowBeg > rowEnd) {
			int tmp = rowBeg;
			rowBeg = rowEnd;
			rowEnd = tmp;
		}
		try {
			List<String> list = new ArrayList<>();
			Set<String> set = new LinkedHashSet<>();
			for (int i=rowBeg; i<=rowEnd; i++) {
				int currRowStart = root.getElement(i).getStartOffset();
				int currRowEnd = root.getElement(i).getEndOffset();
				String currentString = doc.getText(currRowStart, currRowEnd-currRowStart);
				if (coefficient == 0) {
					set.add(currentString);
				} else {
					list.add( currentString );
				}
			}
			
			StringBuilder rowsConcat = new StringBuilder();
			int firstRowStart = root.getElement(rowBeg).getStartOffset();
			int lastRowEnd = root.getElement(rowEnd).getEndOffset();
			doc.remove(firstRowStart, lastRowEnd-firstRowStart-1);
			
			if (coefficient == 0) {
				for (String el: set) {
					rowsConcat.append(el);
				}
			} else {
				Locale locale = new Locale(flp.getCurrentLanguage());
				Collator collator = Collator.getInstance(locale);
				list.sort( (s1, s2) -> (collator.compare(s1, s2) * coefficient) );
				
				for (int i=0; i<list.size(); i++) {
					rowsConcat.append(list.get(i));
				}
			}
			
			doc.insertString(firstRowStart, rowsConcat.toString(), null);
			
		} catch (BadLocationException e1) {
		}
		
	}
	
	/**
	 * Action for sorting all selected lines in ascending order
	 */
	private Action ascending = new LocalizableAction("Ascending", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			ascDescAndUnique(1);
		}
	};
	
	/**
	 * Action for sorting all selected lines in descending order
	 */
	private Action descending = new LocalizableAction("Descending", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			ascDescAndUnique(-1);
		}
	};
	
	/**
	 * Action for removing all duplicate selected lines, leaving 
	 * only first occurrence of each 
	 */
	private Action unique = new LocalizableAction("Unique", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			ascDescAndUnique(0);
		}
	};
	
	private Action deleteRows = new LocalizableAction("Delete", flp) {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int index = model.getSelectedIndex();
			
			String reg = JOptionPane.showInputDialog(null,
					 "Please enter regular expression",
					 "Delete all rows that...",
					 JOptionPane.QUESTION_MESSAGE);
			
			JTextArea textArea = model.getDocument(index).getTextComponent();
			Document doc = model.getDocument(index).getTextComponent().getDocument();
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			
			
			String content = "";
			try {
				content = doc.getText(0, doc.getLength());
				
				doc.remove(0, doc.getLength());
				
				StringBuilder newString = new StringBuilder();
				
				Scanner scanner = new Scanner(content);
				while (scanner.hasNextLine()) {
					String line = scanner.nextLine();
					if (!line.matches(reg)) {
						newString.append(line + "\n");
					}
				}
				
				scanner.close();
				
				doc.insertString(0, newString.toString(), null);
			} catch (BadLocationException ex) {
			}
			
		}
	};
	
	/**
	 * Private helper method for creation of Actions needed for this program
	 */
	private void createActions() {
		newDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
		newDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_N);
		newDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Used to create new documnet.");
		
		openDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
		openDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);
		openDocument.putValue(Action.SHORT_DESCRIPTION, "Used to open existing document.");
		
		saveDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
		saveDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_S);
		saveDocument.putValue(Action.SHORT_DESCRIPTION, "Used to save document.");
		
		saveAsDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control shift S"));
		saveAsDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_F3);
		saveAsDocument.putValue(Action.SHORT_DESCRIPTION, "Used to save as document.");
		
		closeDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control W"));
		closeDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		closeDocument.putValue(Action.SHORT_DESCRIPTION, "Used to close document and tab.");
		
		cutText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control X"));
		cutText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_X);
		cutText.putValue(Action.SHORT_DESCRIPTION, "Used to cut text from document.");
		
		copyText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control C"));
		copyText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		copyText.putValue(Action.SHORT_DESCRIPTION, "Used to copy text from document.");
		
		pasteText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control V"));
		pasteText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_V);
		pasteText.putValue(Action.SHORT_DESCRIPTION, "Used to paste text into a document.");
		
		exitDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control Q"));
		exitDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_Q);
		exitDocument.putValue(Action.SHORT_DESCRIPTION, "Used to close JNotepad++.");
		
		infoOfDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F1"));
		infoOfDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_F1);
		infoOfDocument.putValue(Action.SHORT_DESCRIPTION, "Used to give statistical info on document.");
		
		croatianLanguage.putValue(Action.SHORT_DESCRIPTION, "Used to set language to Croatian.");
		
		englishLanguage.putValue(Action.SHORT_DESCRIPTION, "Used to set language to English.");
		
		germanLanguage.putValue(Action.SHORT_DESCRIPTION, "Used to set language to German.");
		
		uppercase.putValue(Action.SHORT_DESCRIPTION, "Used to change selected text to uppercase.");
		
		lowercase.putValue(Action.SHORT_DESCRIPTION, "Used to change selected text to lowercase.");
		
		invertcase.putValue(Action.SHORT_DESCRIPTION, "Used to change case of selected text.");
		
		ascending.putValue(Action.SHORT_DESCRIPTION, "Used to sort lines in ascending order.");
		
		descending.putValue(Action.SHORT_DESCRIPTION, "Used to sort lines in descending order.");
		
		unique.putValue(Action.SHORT_DESCRIPTION, "Used to remove all non unique selected lines.");
		
		deleteRows.putValue(Action.SHORT_DESCRIPTION, "Used to remove all rows that satisfy given regex.");
	}
	
	/**
	 * Private helper method for creating menu bar
	 */
	private void createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		
		JMenu fileMenu = new LocalizableJMenu("File", flp);
		
		menuBar.add(fileMenu);
		
		fileMenu.add(new JMenuItem(newDocumentAction));
		fileMenu.add(new JMenuItem(openDocument));
		fileMenu.add(new JMenuItem(saveDocument));
		fileMenu.add(new JMenuItem(saveAsDocument));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(closeDocument));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(infoOfDocument));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(exitDocument));
		
		JMenu editMenu = new LocalizableJMenu("Edit", flp);
		menuBar.add(editMenu);
		
		editMenu.add(new JMenuItem(cutText));
		editMenu.add(new JMenuItem(copyText));
		editMenu.add(new JMenuItem(pasteText));
		
		JMenu languagesMenu = new LocalizableJMenu("Languages", flp);
		menuBar.add(languagesMenu);
		
		languagesMenu.add(new JMenuItem(croatianLanguage));
		languagesMenu.add(new JMenuItem(englishLanguage));
		languagesMenu.add(new JMenuItem(germanLanguage));
		
		JMenu toolsMenu = new LocalizableJMenu("Tools", flp);
		JMenu changeCaseMenu = new LocalizableJMenu("Changecase", flp);
		
		upper = new JMenuItem(uppercase);
		lower = new JMenuItem(lowercase);
		invert = new JMenuItem(invertcase);
		changeCaseMenu.add(upper);
		changeCaseMenu.add(lower);
		changeCaseMenu.add(invert);
		toolsMenu.add(changeCaseMenu);
		
		JMenu sortMenu = new LocalizableJMenu("Sort", flp);
		sortMenu.add(new JMenuItem(ascending));
		sortMenu.add(new JMenuItem(descending));
		toolsMenu.add(sortMenu);
		
		toolsMenu.add(new JMenuItem(unique));
		
		toolsMenu.add(new JMenuItem(deleteRows));
		
		menuBar.add(toolsMenu);
		
		this.setJMenuBar(menuBar);
	}
	
	/**
	 * Private helper method for creating tool bar
	 */
	private void createToolbars() {
		JToolBar toolBar = new JToolBar("Tools");
		toolBar.setFloatable(true);
		
		toolBar.add(new JButton(newDocumentAction));
		toolBar.add(new JButton(openDocument));
		toolBar.add(new JButton(saveDocument));
		toolBar.add(new JButton(saveAsDocument));
		toolBar.addSeparator();
		toolBar.add(new JButton(closeDocument));
		toolBar.addSeparator();
		toolBar.add(new JButton(infoOfDocument));
		toolBar.addSeparator();
		toolBar.add(new JButton(exitDocument));
		
		toolBar.addSeparator();
		toolBar.addSeparator();
		
		toolBar.add(new JButton(cutText));
		toolBar.add(new JButton(copyText));
		toolBar.add(new JButton(pasteText));
		
		this.getContentPane().add(toolBar, BorderLayout.PAGE_START);
	}
	
	/**
	 * Main method responsible for starting "JNotepad++"
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			public void run() {
				new JNotepadPP().setVisible(true);
			}
		});
	}
}