package hr.fer.zemris.java.hw11.jnotepadpp;

/**
 * Interface MultipleDocumentListener describes a list of methods every listener 
 * who listens to changes in multiple documents at same time chould implement.
 * 
 * @author Luka Merćep
 *
 */
public interface MultipleDocumentListener {
	
	/**
	 * Method that when implemented does all job after switching 
	 * current model from previousModel to currentModel
	 * 
	 * @param previousModel
	 * @param currentModel
	 */
	void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel);
	
	/**
	 * Method that when implemented does all job after adding
	 * one SingleDocumentModel model
	 * 
	 * @param model
	 */
	void documentAdded(SingleDocumentModel model);
	
	/**
	 * Method that when implemented does all job after removing
	 * one SingleDocumentModel model
	 * 
	 * @param model
	 */
	void documentRemoved(SingleDocumentModel model);
}