package hr.fer.zemris.java.hw11.jnotepadpp;

/**
 * Interface SingleDocumentListener describes a list of methods every listener 
 * who listens to changes in a single document should implement.
 * 
 * @author Luka Merćep
 *
 */
public interface SingleDocumentListener {
	
	/**
	 * Method that when implemented does all job after modify status
	 * of a single document is changed
	 * 
	 * @param model
	 */
	void documentModifyStatusUpdated(SingleDocumentModel model);
	
	/**
	 * Method that when implemented does all job after path of a 
	 * single document is updated
	 * 
	 * @param model
	 */
	void documentFilePathUpdated(SingleDocumentModel model);
}
