package hr.fer.zemris.java.hw11.jnotepadpp.local;

import javax.swing.JMenu;

/**
 * Class LocalizableJMenu extends JMenu and is used for 
 * JMenus whose names should be localizable.
 * 
 * @author Luka Merćep
 *
 */
public class LocalizableJMenu extends JMenu {
	
	/**
	 * String used as key for getting names of this JMenu
	 */
	private String key;
	
	/**
	 * loaclization provider used for localization of this JMenu
	 */
	private ILocalizationProvider lp;
	
	/**
	 * Listener that should be informed when language of localization changes
	 */
	private ILocalizationListener listener;
	
	/**
	 * Constructor for class LocalizableJMenu given its key and 
	 * localization provider.
	 * 
	 * @param key
	 * @param lp
	 */
	public LocalizableJMenu(String key, ILocalizationProvider lp) {
		this.key = key;
		this.lp = lp;
		
		listener = this::updateText;
		
		updateText();
		
		lp.addLocalizationListener(listener);
	}
	
	/**
	 * Method that updates text when language is changed
	 */
	private void updateText() {
		setText(lp.getString(key));
	}
}
