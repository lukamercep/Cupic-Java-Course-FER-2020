package hr.fer.zemris.java.hw11.jnotepadpp.local;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Class LocalizationProvider is used for being a localization provider.
 * It is very important to know that this class is a singleton, and that 
 * means that only one object of this class could exist.
 * 
 * @author Luka Merćep
 *
 */
public class LocalizationProvider extends AbstractLocalizationProvider {
	
	/**
	 * Reference to only object of this class
	 */
	private static final LocalizationProvider instance = new LocalizationProvider();
	
	/**
	 * Language that is currently used for localization
	 */
	private String language;
	
	/**
	 * bundle used for localization
	 */
	private ResourceBundle bundle;
	
	/**
	 * Private constructor for this class.
	 * 
	 * It is very important to notice that this class has only 
	 * one constructor and that it is private, and reason for this is 
	 * that this class is singleton.
	 */
	private LocalizationProvider() {
		language = "en";
		
		Locale locale = Locale.forLanguageTag(language);
		bundle = ResourceBundle.getBundle("hr.fer.zemris.java.hw11.jnotepadpp.local.translation", locale);
	}
	
	/**
	 * Public static method for getting only instance of this class
	 * 
	 * @return
	 */
	public static LocalizationProvider getInstance() {
		return instance;
	}
	
	/**
	 * Method is a setter for a language and it also informs 
	 * all listeners that language has been changed
	 * 
	 * @param language
	 */
	public void setLanguage(String language) {
		this.language = language;
		Locale locale = Locale.forLanguageTag(language);
		bundle = ResourceBundle.getBundle("hr.fer.zemris.java.hw11.jnotepadpp.local.translation", locale);
		fire();
	}
	
	@Override
	public String getCurrentLanguage() {
		return language;
	}

	@Override
	public String getString(String key) {
		return bundle.getString(key);
	}

}
