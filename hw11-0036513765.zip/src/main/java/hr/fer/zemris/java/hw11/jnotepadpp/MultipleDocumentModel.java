package hr.fer.zemris.java.hw11.jnotepadpp;

import java.nio.file.Path;

/**
 * Interface MultipleDocumentModel is a list of methods that 
 * need to be implemented in order to do all needed work 
 * associated with multiple document model
 * 
 * @author Luka Merćep
 *
 */
public interface MultipleDocumentModel extends Iterable<SingleDocumentModel> {
	
	/**
	 * This method creates new (empty) single document model
	 * 
	 * @return
	 */
	SingleDocumentModel createNewDocument();
	
	/**
	 * This model returns current single document model, one that
	 * is shown at the moment.
	 * 
	 * @return
	 */
	SingleDocumentModel getCurrentDocument();
	
	/**
	 * This method is used for loading file from Path path
	 * 
	 * @param path
	 * @return
	 */
	SingleDocumentModel loadDocument(Path path);
	
	/**
	 * This method is used for saving SingleDocumentModel model 
	 * to a Path newPath
	 * 
	 * @param model
	 * @param newPath
	 */
	void saveDocument(SingleDocumentModel model, Path newPath);
	
	/**
	 * This method is used for closing (removing) SingleDocumentModel model 
	 * from this MultipleDocumentModel
	 * 
	 * @param model
	 */
	void closeDocument(SingleDocumentModel model);
	
	/**
	 * Method adds new MultipleDocumentListener l to this 
	 * MultipleDocumentModel.
	 * 
	 * @param l
	 */
	void addMultipleDocumentListener(MultipleDocumentListener l);
	
	/**
	 * Method removes MultipleDocumentListener l from this 
	 * MultipleDocumentModel.
	 * 
	 * @param l
	 */
	void removeMultipleDocumentListener(MultipleDocumentListener l);
	
	/**
	 * Method returns number of SingleDocumentModels this 
	 * MultipleDocumentModel is storing.
	 * 
	 * @return
	 */
	int getNumberOfDocuments();
	
	/**
	 * This method returns SingleDocumentModel model with 
	 * index index.
	 * 
	 * @param index
	 * @return
	 */
	SingleDocumentModel getDocument(int index);
}