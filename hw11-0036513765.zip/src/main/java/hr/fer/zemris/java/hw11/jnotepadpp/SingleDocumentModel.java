package hr.fer.zemris.java.hw11.jnotepadpp;

import java.nio.file.Path;

import javax.swing.JTextArea;

/**
 * Interface SingleDocumentModel is a list of methods who 
 * need to be implemented in order to do all needed work 
 * associated with single document model 
 * 
 * @author Luka Merćep
 *
 */
public interface SingleDocumentModel {
	
	/**
	 * Method returns JTextArea where text of a document is stored
	 * 
	 * @return
	 */
	JTextArea getTextComponent();
	
	
	/**
	 * This method is a getter for file path of a model
	 * 
	 * @return
	 */
	Path getFilePath();
	
	/**
	 * This method is a setter for file path of a model
	 * 
	 * @param path
	 */
	void setFilePath(Path path);
	
	/**
	 * Method returns true is model is modified and false otherwise.
	 * 
	 * @return
	 */
	boolean isModified();
	
	/**
	 * This method is a setter for modified status of a single document model
	 * 
	 * @param modified
	 */
	void setModified(boolean modified);
	
	/**
	 * Method adds new listener to this single document model
	 * 
	 * @param l
	 */
	void addSingleDocumentListener(SingleDocumentListener l);
	
	
	/**
	 * Method removes listener from this single document model
	 * 
	 * @param l
	 */
	void removeSingleDocumentListener(SingleDocumentListener l);
	
}
