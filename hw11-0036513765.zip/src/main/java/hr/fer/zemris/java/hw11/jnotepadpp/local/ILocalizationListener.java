package hr.fer.zemris.java.hw11.jnotepadpp.local;

/**
 * Interface modeling listener for localization changing.
 * 
 * @author Luka Merćep
 *
 */
public interface ILocalizationListener {
	
	/**
	 * Method that when run notifies that localization has beed changed
	 */
	void localizationChanged();
}
